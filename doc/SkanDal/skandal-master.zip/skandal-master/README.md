See http://wiki.labomedia.org/index.php/Cat%C3%A9gorie:Skandal

Tested on Linux Mint 15
with
OpenCV 3.0 and python 3.3

In the skandal directory, open a terminal

 ./scan

You can find the version:

-OpenCV 2.4.2

-python 2.7

at
http://wiki.labomedia.org/index.php/Laser_Scanner_3D_SkanDal_Logiciel#Sources_avec_python_2.7_et_OpenCV_2.4.2

Bugs:

- OpenCV Windows doesn't close with cv2.destroyAllWindows() but the terminal is active.
